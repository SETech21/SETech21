using UnityEngine;
using UnityEngine.UI;

public class Hover : MonoBehaviour
{
    public GameObject Info;
    private Renderer renderer;
    public Text Position;

    public float x;
    public float y;
    public float z;

    void Start()
    {
        renderer = GetComponent<Renderer>();

        x = gameObject.transform.position.x;
        y = gameObject.transform.position.y;
        z = gameObject.transform.position.z;
    }

    private void OnMouseEnter()
    {
        renderer.material.color = Color.gray;
        Info.gameObject.SetActive(true);

        x = gameObject.transform.position.x;
        y = gameObject.transform.position.y;
        z = gameObject.transform.position.z;

        Position.text = "(" + " " + x + ",  " + y + ",  " + z + ")";
    }

    private void OnMouseExit()
    {
        renderer.material.color = Color.white;
        Info.gameObject.SetActive(false);

        x = gameObject.transform.position.x;
        y = gameObject.transform.position.y;
        z = gameObject.transform.position.z;

        Position.text = "(" + " " + x + ",  " + y + ",  " + z + ")";
    }
}
